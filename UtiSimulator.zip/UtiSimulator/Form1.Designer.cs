﻿namespace UtiSimulator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox_COMPORT = new System.Windows.Forms.ComboBox();
            this.button_OpenPort = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.buttonSend = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.buttonPaste = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.textBox64 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox65 = new System.Windows.Forms.TextBox();
            this.textBox66 = new System.Windows.Forms.TextBox();
            this.textBox67 = new System.Windows.Forms.TextBox();
            this.textBox68 = new System.Windows.Forms.TextBox();
            this.textBox69 = new System.Windows.Forms.TextBox();
            this.textBox70 = new System.Windows.Forms.TextBox();
            this.textBox71 = new System.Windows.Forms.TextBox();
            this.textBox72 = new System.Windows.Forms.TextBox();
            this.textBox73 = new System.Windows.Forms.TextBox();
            this.textBox74 = new System.Windows.Forms.TextBox();
            this.textBox75 = new System.Windows.Forms.TextBox();
            this.textBox76 = new System.Windows.Forms.TextBox();
            this.textBox77 = new System.Windows.Forms.TextBox();
            this.textBox78 = new System.Windows.Forms.TextBox();
            this.textBox79 = new System.Windows.Forms.TextBox();
            this.textBox80 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox81 = new System.Windows.Forms.TextBox();
            this.textBox82 = new System.Windows.Forms.TextBox();
            this.textBox83 = new System.Windows.Forms.TextBox();
            this.textBox84 = new System.Windows.Forms.TextBox();
            this.textBox85 = new System.Windows.Forms.TextBox();
            this.textBox86 = new System.Windows.Forms.TextBox();
            this.textBox87 = new System.Windows.Forms.TextBox();
            this.textBox88 = new System.Windows.Forms.TextBox();
            this.textBox89 = new System.Windows.Forms.TextBox();
            this.textBox90 = new System.Windows.Forms.TextBox();
            this.textBox91 = new System.Windows.Forms.TextBox();
            this.textBox92 = new System.Windows.Forms.TextBox();
            this.textBox93 = new System.Windows.Forms.TextBox();
            this.textBox94 = new System.Windows.Forms.TextBox();
            this.textBox95 = new System.Windows.Forms.TextBox();
            this.textBox96 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.buttonClearResults = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.textBoxpi1 = new System.Windows.Forms.TextBox();
            this.textBoxpi2 = new System.Windows.Forms.TextBox();
            this.textBoxpi5 = new System.Windows.Forms.TextBox();
            this.textBoxpi3 = new System.Windows.Forms.TextBox();
            this.textBoxpi6 = new System.Windows.Forms.TextBox();
            this.textBoxpi7 = new System.Windows.Forms.TextBox();
            this.textBoxpi4 = new System.Windows.Forms.TextBox();
            this.textBoxpi8 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.textBoxpi9 = new System.Windows.Forms.TextBox();
            this.textBoxpi10 = new System.Windows.Forms.TextBox();
            this.textBoxpi13 = new System.Windows.Forms.TextBox();
            this.textBoxpi11 = new System.Windows.Forms.TextBox();
            this.textBoxpi14 = new System.Windows.Forms.TextBox();
            this.textBoxpi15 = new System.Windows.Forms.TextBox();
            this.textBoxpi12 = new System.Windows.Forms.TextBox();
            this.textBoxpi16 = new System.Windows.Forms.TextBox();
            this.textBoxpin8 = new System.Windows.Forms.TextBox();
            this.textBoxpin7 = new System.Windows.Forms.TextBox();
            this.textBoxpin6 = new System.Windows.Forms.TextBox();
            this.textBoxpin5 = new System.Windows.Forms.TextBox();
            this.textBoxpin4 = new System.Windows.Forms.TextBox();
            this.textBoxpin3 = new System.Windows.Forms.TextBox();
            this.textBoxpin2 = new System.Windows.Forms.TextBox();
            this.textBoxpin1 = new System.Windows.Forms.TextBox();
            this.textBoxpin16 = new System.Windows.Forms.TextBox();
            this.textBoxpin15 = new System.Windows.Forms.TextBox();
            this.textBoxpin14 = new System.Windows.Forms.TextBox();
            this.textBoxpin13 = new System.Windows.Forms.TextBox();
            this.textBoxpin12 = new System.Windows.Forms.TextBox();
            this.textBoxpin11 = new System.Windows.Forms.TextBox();
            this.textBoxpin10 = new System.Windows.Forms.TextBox();
            this.textBoxpin9 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.No_of_Mins = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBoxMode = new System.Windows.Forms.ComboBox();
            this.buttonSendPi = new System.Windows.Forms.Button();
            this.buttonReceivePiData = new System.Windows.Forms.Button();
            this.buttonValidatePi = new System.Windows.Forms.Button();
            this.buttonValidateASTdata = new System.Windows.Forms.Button();
            this.buttonGetASTresult = new System.Windows.Forms.Button();
            this.textBoxPiResult = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.buttonClearStrips = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.sno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.antibiotic = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.result = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label20 = new System.Windows.Forms.Label();
            this.comboBoxTestName = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.textBoxSWver = new System.Windows.Forms.TextBox();
            this.buttonSWver = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.buttonGetAntibioticName = new System.Windows.Forms.Button();
            this.s_no = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(876, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(154, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Available Com Ports:";
            // 
            // comboBox_COMPORT
            // 
            this.comboBox_COMPORT.BackColor = System.Drawing.Color.AntiqueWhite;
            this.comboBox_COMPORT.Cursor = System.Windows.Forms.Cursors.Default;
            this.comboBox_COMPORT.FormattingEnabled = true;
            this.comboBox_COMPORT.Location = new System.Drawing.Point(1036, 20);
            this.comboBox_COMPORT.Name = "comboBox_COMPORT";
            this.comboBox_COMPORT.Size = new System.Drawing.Size(93, 21);
            this.comboBox_COMPORT.TabIndex = 1;
            // 
            // button_OpenPort
            // 
            this.button_OpenPort.BackColor = System.Drawing.Color.DarkOrange;
            this.button_OpenPort.Location = new System.Drawing.Point(1135, 18);
            this.button_OpenPort.Name = "button_OpenPort";
            this.button_OpenPort.Size = new System.Drawing.Size(75, 23);
            this.button_OpenPort.TabIndex = 2;
            this.button_OpenPort.Text = "Open Port";
            this.button_OpenPort.UseVisualStyleBackColor = false;
            this.button_OpenPort.Click += new System.EventHandler(this.button_OpenPort_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 654);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1343, 30);
            this.statusStrip1.TabIndex = 3;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(79, 25);
            this.toolStripStatusLabel1.Text = "STATUS:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.OldLace;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Fuchsia;
            this.label5.Location = new System.Drawing.Point(368, 151);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 16);
            this.label5.TabIndex = 5;
            this.label5.Text = "P1 450nm";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox1.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox1.Location = new System.Drawing.Point(370, 173);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(53, 20);
            this.textBox1.TabIndex = 5;
            this.textBox1.Text = "0.0";
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox2.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox2.Location = new System.Drawing.Point(370, 199);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(53, 20);
            this.textBox2.TabIndex = 6;
            this.textBox2.Text = "0.0";
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox3.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox3.Location = new System.Drawing.Point(370, 225);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(53, 20);
            this.textBox3.TabIndex = 7;
            this.textBox3.Text = "0.0";
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox4.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox4.Location = new System.Drawing.Point(370, 251);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(53, 20);
            this.textBox4.TabIndex = 8;
            this.textBox4.Text = "0.0";
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox5.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox5.Location = new System.Drawing.Point(370, 277);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(53, 20);
            this.textBox5.TabIndex = 9;
            this.textBox5.Text = "0.0";
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox6.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox6.Location = new System.Drawing.Point(370, 303);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(53, 20);
            this.textBox6.TabIndex = 10;
            this.textBox6.Text = "0.0";
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox7.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox7.Location = new System.Drawing.Point(370, 329);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(53, 20);
            this.textBox7.TabIndex = 11;
            this.textBox7.Text = "0.0";
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox8.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox8.Location = new System.Drawing.Point(370, 355);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(53, 20);
            this.textBox8.TabIndex = 12;
            this.textBox8.Text = "0.0";
            // 
            // textBox16
            // 
            this.textBox16.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox16.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox16.Location = new System.Drawing.Point(454, 355);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(53, 20);
            this.textBox16.TabIndex = 20;
            this.textBox16.Text = "0.0";
            // 
            // textBox12
            // 
            this.textBox12.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox12.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox12.Location = new System.Drawing.Point(454, 251);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(53, 20);
            this.textBox12.TabIndex = 16;
            this.textBox12.Text = "0.0";
            // 
            // textBox15
            // 
            this.textBox15.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox15.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox15.Location = new System.Drawing.Point(454, 329);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(53, 20);
            this.textBox15.TabIndex = 19;
            this.textBox15.Text = "0.0";
            // 
            // textBox14
            // 
            this.textBox14.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox14.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox14.Location = new System.Drawing.Point(454, 303);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(53, 20);
            this.textBox14.TabIndex = 18;
            this.textBox14.Text = "0.0";
            // 
            // textBox11
            // 
            this.textBox11.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox11.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox11.Location = new System.Drawing.Point(454, 225);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(53, 20);
            this.textBox11.TabIndex = 15;
            this.textBox11.Text = "0.0";
            // 
            // textBox13
            // 
            this.textBox13.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox13.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox13.Location = new System.Drawing.Point(454, 277);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(53, 20);
            this.textBox13.TabIndex = 17;
            this.textBox13.Text = "0.0";
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox10.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox10.Location = new System.Drawing.Point(454, 199);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(53, 20);
            this.textBox10.TabIndex = 14;
            this.textBox10.Text = "0.0";
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox9.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox9.Location = new System.Drawing.Point(454, 173);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(53, 20);
            this.textBox9.TabIndex = 13;
            this.textBox9.Text = "0.0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.OldLace;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Fuchsia;
            this.label6.Location = new System.Drawing.Point(451, 151);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 16);
            this.label6.TabIndex = 14;
            this.label6.Text = "P1 630nm";
            // 
            // textBox17
            // 
            this.textBox17.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox17.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox17.Location = new System.Drawing.Point(535, 173);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(53, 20);
            this.textBox17.TabIndex = 21;
            this.textBox17.Text = "0.0";
            // 
            // textBox18
            // 
            this.textBox18.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox18.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox18.Location = new System.Drawing.Point(535, 199);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(53, 20);
            this.textBox18.TabIndex = 22;
            this.textBox18.Text = "0.0";
            // 
            // textBox19
            // 
            this.textBox19.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox19.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox19.Location = new System.Drawing.Point(535, 225);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(53, 20);
            this.textBox19.TabIndex = 23;
            this.textBox19.Text = "0.0";
            // 
            // textBox20
            // 
            this.textBox20.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox20.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox20.Location = new System.Drawing.Point(535, 251);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(53, 20);
            this.textBox20.TabIndex = 24;
            this.textBox20.Text = "0.0";
            // 
            // textBox21
            // 
            this.textBox21.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox21.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox21.Location = new System.Drawing.Point(535, 277);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(53, 20);
            this.textBox21.TabIndex = 25;
            this.textBox21.Text = "0.0";
            // 
            // textBox22
            // 
            this.textBox22.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox22.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox22.Location = new System.Drawing.Point(535, 303);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(53, 20);
            this.textBox22.TabIndex = 26;
            this.textBox22.Text = "0.0";
            // 
            // textBox23
            // 
            this.textBox23.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox23.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox23.Location = new System.Drawing.Point(535, 329);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(53, 20);
            this.textBox23.TabIndex = 27;
            this.textBox23.Text = "0.0";
            // 
            // textBox24
            // 
            this.textBox24.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox24.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox24.Location = new System.Drawing.Point(535, 355);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(53, 20);
            this.textBox24.TabIndex = 28;
            this.textBox24.Text = "0.0";
            // 
            // textBox25
            // 
            this.textBox25.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox25.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox25.Location = new System.Drawing.Point(619, 173);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(53, 20);
            this.textBox25.TabIndex = 29;
            this.textBox25.Text = "0.0";
            // 
            // textBox26
            // 
            this.textBox26.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox26.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox26.Location = new System.Drawing.Point(619, 199);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(53, 20);
            this.textBox26.TabIndex = 30;
            this.textBox26.Text = "0.0";
            // 
            // textBox27
            // 
            this.textBox27.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox27.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox27.Location = new System.Drawing.Point(619, 225);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(53, 20);
            this.textBox27.TabIndex = 31;
            this.textBox27.Text = "0.0";
            // 
            // textBox28
            // 
            this.textBox28.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox28.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox28.Location = new System.Drawing.Point(619, 251);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(53, 20);
            this.textBox28.TabIndex = 32;
            this.textBox28.Text = "0.0";
            // 
            // textBox29
            // 
            this.textBox29.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox29.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox29.Location = new System.Drawing.Point(619, 277);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(53, 20);
            this.textBox29.TabIndex = 33;
            this.textBox29.Text = "0.0";
            // 
            // textBox30
            // 
            this.textBox30.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox30.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox30.Location = new System.Drawing.Point(619, 303);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(53, 20);
            this.textBox30.TabIndex = 34;
            this.textBox30.Text = "0.0";
            // 
            // textBox31
            // 
            this.textBox31.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox31.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox31.Location = new System.Drawing.Point(619, 329);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(53, 20);
            this.textBox31.TabIndex = 35;
            this.textBox31.Text = "0.0";
            // 
            // textBox32
            // 
            this.textBox32.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox32.ForeColor = System.Drawing.Color.Fuchsia;
            this.textBox32.Location = new System.Drawing.Point(619, 355);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(53, 20);
            this.textBox32.TabIndex = 36;
            this.textBox32.Text = "0.0";
            // 
            // textBox33
            // 
            this.textBox33.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox33.ForeColor = System.Drawing.Color.Green;
            this.textBox33.Location = new System.Drawing.Point(713, 173);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(53, 20);
            this.textBox33.TabIndex = 37;
            this.textBox33.Text = "0.0";
            // 
            // textBox34
            // 
            this.textBox34.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox34.ForeColor = System.Drawing.Color.Green;
            this.textBox34.Location = new System.Drawing.Point(713, 199);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(53, 20);
            this.textBox34.TabIndex = 38;
            this.textBox34.Text = "0.0";
            // 
            // textBox35
            // 
            this.textBox35.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox35.ForeColor = System.Drawing.Color.Green;
            this.textBox35.Location = new System.Drawing.Point(713, 225);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(53, 20);
            this.textBox35.TabIndex = 39;
            this.textBox35.Text = "0.0";
            // 
            // textBox36
            // 
            this.textBox36.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox36.ForeColor = System.Drawing.Color.Green;
            this.textBox36.Location = new System.Drawing.Point(713, 251);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(53, 20);
            this.textBox36.TabIndex = 40;
            this.textBox36.Text = "0.0";
            // 
            // textBox37
            // 
            this.textBox37.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox37.ForeColor = System.Drawing.Color.Green;
            this.textBox37.Location = new System.Drawing.Point(713, 277);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(53, 20);
            this.textBox37.TabIndex = 41;
            this.textBox37.Text = "0.0";
            // 
            // textBox38
            // 
            this.textBox38.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox38.ForeColor = System.Drawing.Color.Green;
            this.textBox38.Location = new System.Drawing.Point(713, 303);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(53, 20);
            this.textBox38.TabIndex = 42;
            this.textBox38.Text = "0.0";
            // 
            // textBox39
            // 
            this.textBox39.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox39.ForeColor = System.Drawing.Color.Green;
            this.textBox39.Location = new System.Drawing.Point(713, 329);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(53, 20);
            this.textBox39.TabIndex = 43;
            this.textBox39.Text = "0.0";
            // 
            // textBox40
            // 
            this.textBox40.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox40.ForeColor = System.Drawing.Color.Green;
            this.textBox40.Location = new System.Drawing.Point(713, 355);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(53, 20);
            this.textBox40.TabIndex = 44;
            this.textBox40.Text = "0.0";
            // 
            // textBox41
            // 
            this.textBox41.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox41.ForeColor = System.Drawing.Color.Green;
            this.textBox41.Location = new System.Drawing.Point(792, 173);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(53, 20);
            this.textBox41.TabIndex = 45;
            this.textBox41.Text = "0.0";
            // 
            // textBox42
            // 
            this.textBox42.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox42.ForeColor = System.Drawing.Color.Green;
            this.textBox42.Location = new System.Drawing.Point(792, 199);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(53, 20);
            this.textBox42.TabIndex = 46;
            this.textBox42.Text = "0.0";
            // 
            // textBox43
            // 
            this.textBox43.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox43.ForeColor = System.Drawing.Color.Green;
            this.textBox43.Location = new System.Drawing.Point(792, 225);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(53, 20);
            this.textBox43.TabIndex = 47;
            this.textBox43.Text = "0.0";
            // 
            // textBox44
            // 
            this.textBox44.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox44.ForeColor = System.Drawing.Color.Green;
            this.textBox44.Location = new System.Drawing.Point(792, 251);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(53, 20);
            this.textBox44.TabIndex = 48;
            this.textBox44.Text = "0.0";
            // 
            // textBox45
            // 
            this.textBox45.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox45.ForeColor = System.Drawing.Color.Green;
            this.textBox45.Location = new System.Drawing.Point(792, 277);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(53, 20);
            this.textBox45.TabIndex = 49;
            this.textBox45.Text = "0.0";
            // 
            // textBox46
            // 
            this.textBox46.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox46.ForeColor = System.Drawing.Color.Green;
            this.textBox46.Location = new System.Drawing.Point(792, 303);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(53, 20);
            this.textBox46.TabIndex = 50;
            this.textBox46.Text = "0.0";
            // 
            // textBox47
            // 
            this.textBox47.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox47.ForeColor = System.Drawing.Color.Green;
            this.textBox47.Location = new System.Drawing.Point(792, 329);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(53, 20);
            this.textBox47.TabIndex = 51;
            this.textBox47.Text = "0.0";
            // 
            // textBox48
            // 
            this.textBox48.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox48.ForeColor = System.Drawing.Color.Green;
            this.textBox48.Location = new System.Drawing.Point(792, 355);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(53, 20);
            this.textBox48.TabIndex = 52;
            this.textBox48.Text = "0.0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.OldLace;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Fuchsia;
            this.label8.Location = new System.Drawing.Point(616, 151);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 16);
            this.label8.TabIndex = 54;
            this.label8.Text = "P2 630nm";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.OldLace;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Fuchsia;
            this.label9.Location = new System.Drawing.Point(532, 151);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(74, 16);
            this.label9.TabIndex = 53;
            this.label9.Text = "P2 450nm";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.OldLace;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Green;
            this.label10.Location = new System.Drawing.Point(789, 151);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(74, 16);
            this.label10.TabIndex = 56;
            this.label10.Text = "P3 630nm";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.OldLace;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Green;
            this.label11.Location = new System.Drawing.Point(710, 151);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(74, 16);
            this.label11.TabIndex = 55;
            this.label11.Text = "P3 450nm";
            // 
            // buttonSend
            // 
            this.buttonSend.BackColor = System.Drawing.Color.Pink;
            this.buttonSend.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.5F);
            this.buttonSend.Location = new System.Drawing.Point(371, 67);
            this.buttonSend.Name = "buttonSend";
            this.buttonSend.Size = new System.Drawing.Size(150, 37);
            this.buttonSend.TabIndex = 57;
            this.buttonSend.Text = "Send AST Data";
            this.buttonSend.UseVisualStyleBackColor = false;
            this.buttonSend.Click += new System.EventHandler(this.buttonSend_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(1105, 142);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(116, 25);
            this.label12.TabIndex = 60;
            this.label12.Text = "RESULTS";
            // 
            // buttonPaste
            // 
            this.buttonPaste.BackColor = System.Drawing.Color.Yellow;
            this.buttonPaste.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.5F);
            this.buttonPaste.Location = new System.Drawing.Point(6, 513);
            this.buttonPaste.Name = "buttonPaste";
            this.buttonPaste.Size = new System.Drawing.Size(306, 36);
            this.buttonPaste.TabIndex = 61;
            this.buttonPaste.Text = "Paste Panel Data From Exel ClipBoard";
            this.buttonPaste.UseVisualStyleBackColor = false;
            this.buttonPaste.Click += new System.EventHandler(this.buttonPaste_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.BackColor = System.Drawing.Color.Tomato;
            this.buttonExit.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonExit.Location = new System.Drawing.Point(141, 615);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(93, 36);
            this.buttonExit.TabIndex = 62;
            this.buttonExit.Text = "E&xit";
            this.buttonExit.UseVisualStyleBackColor = false;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.OldLace;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Green;
            this.label13.Location = new System.Drawing.Point(951, 151);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(74, 16);
            this.label13.TabIndex = 80;
            this.label13.Text = "P4 630nm";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.OldLace;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Green;
            this.label14.Location = new System.Drawing.Point(867, 151);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(74, 16);
            this.label14.TabIndex = 79;
            this.label14.Text = "P4 450nm";
            // 
            // textBox49
            // 
            this.textBox49.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox49.ForeColor = System.Drawing.Color.Green;
            this.textBox49.Location = new System.Drawing.Point(870, 173);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(53, 20);
            this.textBox49.TabIndex = 53;
            this.textBox49.Text = "0.0";
            // 
            // textBox50
            // 
            this.textBox50.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox50.ForeColor = System.Drawing.Color.Green;
            this.textBox50.Location = new System.Drawing.Point(870, 199);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(53, 20);
            this.textBox50.TabIndex = 54;
            this.textBox50.Text = "0.0";
            // 
            // textBox51
            // 
            this.textBox51.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox51.ForeColor = System.Drawing.Color.Green;
            this.textBox51.Location = new System.Drawing.Point(870, 225);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(53, 20);
            this.textBox51.TabIndex = 55;
            this.textBox51.Text = "0.0";
            // 
            // textBox52
            // 
            this.textBox52.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox52.ForeColor = System.Drawing.Color.Green;
            this.textBox52.Location = new System.Drawing.Point(870, 251);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(53, 20);
            this.textBox52.TabIndex = 56;
            this.textBox52.Text = "0.0";
            // 
            // textBox53
            // 
            this.textBox53.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox53.ForeColor = System.Drawing.Color.Green;
            this.textBox53.Location = new System.Drawing.Point(870, 277);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(53, 20);
            this.textBox53.TabIndex = 57;
            this.textBox53.Text = "0.0";
            // 
            // textBox54
            // 
            this.textBox54.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox54.ForeColor = System.Drawing.Color.Green;
            this.textBox54.Location = new System.Drawing.Point(870, 303);
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(53, 20);
            this.textBox54.TabIndex = 58;
            this.textBox54.Text = "0.0";
            // 
            // textBox55
            // 
            this.textBox55.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox55.ForeColor = System.Drawing.Color.Green;
            this.textBox55.Location = new System.Drawing.Point(870, 329);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(53, 20);
            this.textBox55.TabIndex = 59;
            this.textBox55.Text = "0.0";
            // 
            // textBox56
            // 
            this.textBox56.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox56.ForeColor = System.Drawing.Color.Green;
            this.textBox56.Location = new System.Drawing.Point(870, 355);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(53, 20);
            this.textBox56.TabIndex = 60;
            this.textBox56.Text = "0.0";
            // 
            // textBox57
            // 
            this.textBox57.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox57.ForeColor = System.Drawing.Color.Green;
            this.textBox57.Location = new System.Drawing.Point(956, 173);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(53, 20);
            this.textBox57.TabIndex = 61;
            this.textBox57.Text = "0.0";
            // 
            // textBox58
            // 
            this.textBox58.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox58.ForeColor = System.Drawing.Color.Green;
            this.textBox58.Location = new System.Drawing.Point(956, 199);
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(53, 20);
            this.textBox58.TabIndex = 62;
            this.textBox58.Text = "0.0";
            // 
            // textBox59
            // 
            this.textBox59.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox59.ForeColor = System.Drawing.Color.Green;
            this.textBox59.Location = new System.Drawing.Point(956, 225);
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(53, 20);
            this.textBox59.TabIndex = 63;
            this.textBox59.Text = "0.0";
            // 
            // textBox60
            // 
            this.textBox60.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox60.ForeColor = System.Drawing.Color.Green;
            this.textBox60.Location = new System.Drawing.Point(956, 251);
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(53, 20);
            this.textBox60.TabIndex = 64;
            this.textBox60.Text = "0.0";
            // 
            // textBox61
            // 
            this.textBox61.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox61.ForeColor = System.Drawing.Color.Green;
            this.textBox61.Location = new System.Drawing.Point(956, 277);
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(53, 20);
            this.textBox61.TabIndex = 65;
            this.textBox61.Text = "0.0";
            // 
            // textBox62
            // 
            this.textBox62.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox62.ForeColor = System.Drawing.Color.Green;
            this.textBox62.Location = new System.Drawing.Point(956, 303);
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(53, 20);
            this.textBox62.TabIndex = 66;
            this.textBox62.Text = "0.0";
            // 
            // textBox63
            // 
            this.textBox63.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox63.ForeColor = System.Drawing.Color.Green;
            this.textBox63.Location = new System.Drawing.Point(956, 329);
            this.textBox63.Name = "textBox63";
            this.textBox63.Size = new System.Drawing.Size(53, 20);
            this.textBox63.TabIndex = 67;
            this.textBox63.Text = "0.0";
            // 
            // textBox64
            // 
            this.textBox64.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox64.ForeColor = System.Drawing.Color.Green;
            this.textBox64.Location = new System.Drawing.Point(956, 355);
            this.textBox64.Name = "textBox64";
            this.textBox64.Size = new System.Drawing.Size(53, 20);
            this.textBox64.TabIndex = 68;
            this.textBox64.Text = "0.0";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.OldLace;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label15.Location = new System.Drawing.Point(447, 391);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(74, 16);
            this.label15.TabIndex = 98;
            this.label15.Text = "P5 630nm";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.OldLace;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label16.Location = new System.Drawing.Point(363, 391);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(74, 16);
            this.label16.TabIndex = 97;
            this.label16.Text = "P5 450nm";
            // 
            // textBox65
            // 
            this.textBox65.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox65.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.textBox65.Location = new System.Drawing.Point(363, 409);
            this.textBox65.Name = "textBox65";
            this.textBox65.Size = new System.Drawing.Size(53, 20);
            this.textBox65.TabIndex = 69;
            this.textBox65.Text = "0.0";
            // 
            // textBox66
            // 
            this.textBox66.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox66.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.textBox66.Location = new System.Drawing.Point(363, 435);
            this.textBox66.Name = "textBox66";
            this.textBox66.Size = new System.Drawing.Size(53, 20);
            this.textBox66.TabIndex = 70;
            this.textBox66.Text = "0.0";
            // 
            // textBox67
            // 
            this.textBox67.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox67.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.textBox67.Location = new System.Drawing.Point(363, 461);
            this.textBox67.Name = "textBox67";
            this.textBox67.Size = new System.Drawing.Size(53, 20);
            this.textBox67.TabIndex = 71;
            this.textBox67.Text = "0.0";
            // 
            // textBox68
            // 
            this.textBox68.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox68.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.textBox68.Location = new System.Drawing.Point(363, 487);
            this.textBox68.Name = "textBox68";
            this.textBox68.Size = new System.Drawing.Size(53, 20);
            this.textBox68.TabIndex = 72;
            this.textBox68.Text = "0.0";
            // 
            // textBox69
            // 
            this.textBox69.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox69.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.textBox69.Location = new System.Drawing.Point(363, 513);
            this.textBox69.Name = "textBox69";
            this.textBox69.Size = new System.Drawing.Size(53, 20);
            this.textBox69.TabIndex = 73;
            this.textBox69.Text = "0.0";
            // 
            // textBox70
            // 
            this.textBox70.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox70.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.textBox70.Location = new System.Drawing.Point(363, 539);
            this.textBox70.Name = "textBox70";
            this.textBox70.Size = new System.Drawing.Size(53, 20);
            this.textBox70.TabIndex = 74;
            this.textBox70.Text = "0.0";
            // 
            // textBox71
            // 
            this.textBox71.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox71.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.textBox71.Location = new System.Drawing.Point(363, 565);
            this.textBox71.Name = "textBox71";
            this.textBox71.Size = new System.Drawing.Size(53, 20);
            this.textBox71.TabIndex = 75;
            this.textBox71.Text = "0.0";
            // 
            // textBox72
            // 
            this.textBox72.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox72.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.textBox72.Location = new System.Drawing.Point(363, 591);
            this.textBox72.Name = "textBox72";
            this.textBox72.Size = new System.Drawing.Size(53, 20);
            this.textBox72.TabIndex = 76;
            this.textBox72.Text = "0.0";
            // 
            // textBox73
            // 
            this.textBox73.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox73.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.textBox73.Location = new System.Drawing.Point(449, 409);
            this.textBox73.Name = "textBox73";
            this.textBox73.Size = new System.Drawing.Size(53, 20);
            this.textBox73.TabIndex = 77;
            this.textBox73.Text = "0.0";
            // 
            // textBox74
            // 
            this.textBox74.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox74.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.textBox74.Location = new System.Drawing.Point(449, 435);
            this.textBox74.Name = "textBox74";
            this.textBox74.Size = new System.Drawing.Size(53, 20);
            this.textBox74.TabIndex = 78;
            this.textBox74.Text = "0.0";
            // 
            // textBox75
            // 
            this.textBox75.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox75.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.textBox75.Location = new System.Drawing.Point(449, 461);
            this.textBox75.Name = "textBox75";
            this.textBox75.Size = new System.Drawing.Size(53, 20);
            this.textBox75.TabIndex = 79;
            this.textBox75.Text = "0.0";
            // 
            // textBox76
            // 
            this.textBox76.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox76.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.textBox76.Location = new System.Drawing.Point(449, 487);
            this.textBox76.Name = "textBox76";
            this.textBox76.Size = new System.Drawing.Size(53, 20);
            this.textBox76.TabIndex = 80;
            this.textBox76.Text = "0.0";
            // 
            // textBox77
            // 
            this.textBox77.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox77.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.textBox77.Location = new System.Drawing.Point(449, 513);
            this.textBox77.Name = "textBox77";
            this.textBox77.Size = new System.Drawing.Size(53, 20);
            this.textBox77.TabIndex = 81;
            this.textBox77.Text = "0.0";
            // 
            // textBox78
            // 
            this.textBox78.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox78.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.textBox78.Location = new System.Drawing.Point(449, 539);
            this.textBox78.Name = "textBox78";
            this.textBox78.Size = new System.Drawing.Size(53, 20);
            this.textBox78.TabIndex = 82;
            this.textBox78.Text = "0.0";
            // 
            // textBox79
            // 
            this.textBox79.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox79.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.textBox79.Location = new System.Drawing.Point(449, 565);
            this.textBox79.Name = "textBox79";
            this.textBox79.Size = new System.Drawing.Size(53, 20);
            this.textBox79.TabIndex = 83;
            this.textBox79.Text = "0.0";
            // 
            // textBox80
            // 
            this.textBox80.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox80.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.textBox80.Location = new System.Drawing.Point(449, 591);
            this.textBox80.Name = "textBox80";
            this.textBox80.Size = new System.Drawing.Size(53, 20);
            this.textBox80.TabIndex = 84;
            this.textBox80.Text = "0.0";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.OldLace;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Teal;
            this.label17.Location = new System.Drawing.Point(621, 390);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(74, 16);
            this.label17.TabIndex = 116;
            this.label17.Text = "P6 630nm";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.OldLace;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Teal;
            this.label18.Location = new System.Drawing.Point(537, 390);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(74, 16);
            this.label18.TabIndex = 115;
            this.label18.Text = "P6 450nm";
            // 
            // textBox81
            // 
            this.textBox81.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox81.ForeColor = System.Drawing.Color.Teal;
            this.textBox81.Location = new System.Drawing.Point(538, 409);
            this.textBox81.Name = "textBox81";
            this.textBox81.Size = new System.Drawing.Size(53, 20);
            this.textBox81.TabIndex = 85;
            this.textBox81.Text = "0.0";
            // 
            // textBox82
            // 
            this.textBox82.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox82.ForeColor = System.Drawing.Color.Teal;
            this.textBox82.Location = new System.Drawing.Point(538, 435);
            this.textBox82.Name = "textBox82";
            this.textBox82.Size = new System.Drawing.Size(53, 20);
            this.textBox82.TabIndex = 186;
            this.textBox82.Text = "0.0";
            // 
            // textBox83
            // 
            this.textBox83.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox83.ForeColor = System.Drawing.Color.Teal;
            this.textBox83.Location = new System.Drawing.Point(538, 461);
            this.textBox83.Name = "textBox83";
            this.textBox83.Size = new System.Drawing.Size(53, 20);
            this.textBox83.TabIndex = 87;
            this.textBox83.Text = "0.0";
            // 
            // textBox84
            // 
            this.textBox84.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox84.ForeColor = System.Drawing.Color.Teal;
            this.textBox84.Location = new System.Drawing.Point(538, 487);
            this.textBox84.Name = "textBox84";
            this.textBox84.Size = new System.Drawing.Size(53, 20);
            this.textBox84.TabIndex = 88;
            this.textBox84.Text = "0.0";
            // 
            // textBox85
            // 
            this.textBox85.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox85.ForeColor = System.Drawing.Color.Teal;
            this.textBox85.Location = new System.Drawing.Point(538, 513);
            this.textBox85.Name = "textBox85";
            this.textBox85.Size = new System.Drawing.Size(53, 20);
            this.textBox85.TabIndex = 89;
            this.textBox85.Text = "0.0";
            // 
            // textBox86
            // 
            this.textBox86.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox86.ForeColor = System.Drawing.Color.Teal;
            this.textBox86.Location = new System.Drawing.Point(538, 539);
            this.textBox86.Name = "textBox86";
            this.textBox86.Size = new System.Drawing.Size(53, 20);
            this.textBox86.TabIndex = 90;
            this.textBox86.Text = "0.0";
            // 
            // textBox87
            // 
            this.textBox87.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox87.ForeColor = System.Drawing.Color.Teal;
            this.textBox87.Location = new System.Drawing.Point(538, 565);
            this.textBox87.Name = "textBox87";
            this.textBox87.Size = new System.Drawing.Size(53, 20);
            this.textBox87.TabIndex = 91;
            this.textBox87.Text = "0.0";
            // 
            // textBox88
            // 
            this.textBox88.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox88.ForeColor = System.Drawing.Color.Teal;
            this.textBox88.Location = new System.Drawing.Point(538, 591);
            this.textBox88.Name = "textBox88";
            this.textBox88.Size = new System.Drawing.Size(53, 20);
            this.textBox88.TabIndex = 92;
            this.textBox88.Text = "0.0";
            // 
            // textBox89
            // 
            this.textBox89.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox89.ForeColor = System.Drawing.Color.Teal;
            this.textBox89.Location = new System.Drawing.Point(624, 409);
            this.textBox89.Name = "textBox89";
            this.textBox89.Size = new System.Drawing.Size(53, 20);
            this.textBox89.TabIndex = 93;
            this.textBox89.Text = "0.0";
            // 
            // textBox90
            // 
            this.textBox90.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox90.ForeColor = System.Drawing.Color.Teal;
            this.textBox90.Location = new System.Drawing.Point(624, 435);
            this.textBox90.Name = "textBox90";
            this.textBox90.Size = new System.Drawing.Size(53, 20);
            this.textBox90.TabIndex = 94;
            this.textBox90.Text = "0.0";
            // 
            // textBox91
            // 
            this.textBox91.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox91.ForeColor = System.Drawing.Color.Teal;
            this.textBox91.Location = new System.Drawing.Point(624, 461);
            this.textBox91.Name = "textBox91";
            this.textBox91.Size = new System.Drawing.Size(53, 20);
            this.textBox91.TabIndex = 95;
            this.textBox91.Text = "0.0";
            // 
            // textBox92
            // 
            this.textBox92.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox92.ForeColor = System.Drawing.Color.Teal;
            this.textBox92.Location = new System.Drawing.Point(624, 487);
            this.textBox92.Name = "textBox92";
            this.textBox92.Size = new System.Drawing.Size(53, 20);
            this.textBox92.TabIndex = 96;
            this.textBox92.Text = "0.0";
            // 
            // textBox93
            // 
            this.textBox93.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox93.ForeColor = System.Drawing.Color.Teal;
            this.textBox93.Location = new System.Drawing.Point(624, 513);
            this.textBox93.Name = "textBox93";
            this.textBox93.Size = new System.Drawing.Size(53, 20);
            this.textBox93.TabIndex = 97;
            this.textBox93.Text = "0.0";
            // 
            // textBox94
            // 
            this.textBox94.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox94.ForeColor = System.Drawing.Color.Teal;
            this.textBox94.Location = new System.Drawing.Point(624, 539);
            this.textBox94.Name = "textBox94";
            this.textBox94.Size = new System.Drawing.Size(53, 20);
            this.textBox94.TabIndex = 98;
            this.textBox94.Text = "0.0";
            // 
            // textBox95
            // 
            this.textBox95.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox95.ForeColor = System.Drawing.Color.Teal;
            this.textBox95.Location = new System.Drawing.Point(624, 565);
            this.textBox95.Name = "textBox95";
            this.textBox95.Size = new System.Drawing.Size(53, 20);
            this.textBox95.TabIndex = 99;
            this.textBox95.Text = "0.0";
            // 
            // textBox96
            // 
            this.textBox96.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox96.ForeColor = System.Drawing.Color.Teal;
            this.textBox96.Location = new System.Drawing.Point(624, 591);
            this.textBox96.Name = "textBox96";
            this.textBox96.Size = new System.Drawing.Size(53, 20);
            this.textBox96.TabIndex = 100;
            this.textBox96.Text = "0.0";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Bisque;
            this.groupBox1.Controls.Add(this.checkBox6);
            this.groupBox1.Controls.Add(this.checkBox5);
            this.groupBox1.Controls.Add(this.checkBox4);
            this.groupBox1.Controls.Add(this.checkBox3);
            this.groupBox1.Controls.Add(this.checkBox2);
            this.groupBox1.Controls.Add(this.checkBox1);
            this.groupBox1.Font = new System.Drawing.Font("MS Reference Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(713, 397);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(165, 231);
            this.groupBox1.TabIndex = 204;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Strips to be Tested";
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Font = new System.Drawing.Font("Consolas", 12F);
            this.checkBox6.Location = new System.Drawing.Point(43, 167);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(91, 23);
            this.checkBox6.TabIndex = 0;
            this.checkBox6.Text = "STRIP 6";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Font = new System.Drawing.Font("Consolas", 12F);
            this.checkBox5.Location = new System.Drawing.Point(43, 138);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(91, 23);
            this.checkBox5.TabIndex = 0;
            this.checkBox5.Text = "STRIP 5";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Font = new System.Drawing.Font("Consolas", 12F);
            this.checkBox4.Location = new System.Drawing.Point(43, 109);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(91, 23);
            this.checkBox4.TabIndex = 0;
            this.checkBox4.Text = "STRIP 4";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Font = new System.Drawing.Font("Consolas", 12F);
            this.checkBox3.Location = new System.Drawing.Point(43, 80);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(91, 23);
            this.checkBox3.TabIndex = 0;
            this.checkBox3.Text = "STRIP 3";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Font = new System.Drawing.Font("Consolas", 12F);
            this.checkBox2.Location = new System.Drawing.Point(43, 51);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(91, 23);
            this.checkBox2.TabIndex = 0;
            this.checkBox2.Text = "STRIP 2";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Consolas", 12F);
            this.checkBox1.Location = new System.Drawing.Point(43, 22);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(91, 23);
            this.checkBox1.TabIndex = 0;
            this.checkBox1.Text = "STRIP 1";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // buttonClearResults
            // 
            this.buttonClearResults.BackColor = System.Drawing.Color.Cyan;
            this.buttonClearResults.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.5F);
            this.buttonClearResults.Location = new System.Drawing.Point(1098, 67);
            this.buttonClearResults.Name = "buttonClearResults";
            this.buttonClearResults.Size = new System.Drawing.Size(150, 36);
            this.buttonClearResults.TabIndex = 58;
            this.buttonClearResults.Text = "Clear Results";
            this.buttonClearResults.UseVisualStyleBackColor = false;
            this.buttonClearResults.Click += new System.EventHandler(this.buttonClearResults_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.OldLace;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Red;
            this.label19.Location = new System.Drawing.Point(3, 151);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(70, 16);
            this.label19.TabIndex = 5;
            this.label19.Text = "Pi 450nm";
            // 
            // textBoxpi1
            // 
            this.textBoxpi1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpi1.ForeColor = System.Drawing.Color.Red;
            this.textBoxpi1.Location = new System.Drawing.Point(6, 173);
            this.textBoxpi1.Name = "textBoxpi1";
            this.textBoxpi1.Size = new System.Drawing.Size(53, 20);
            this.textBoxpi1.TabIndex = 5;
            this.textBoxpi1.Text = "0.0";
            // 
            // textBoxpi2
            // 
            this.textBoxpi2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpi2.ForeColor = System.Drawing.Color.Red;
            this.textBoxpi2.Location = new System.Drawing.Point(6, 199);
            this.textBoxpi2.Name = "textBoxpi2";
            this.textBoxpi2.Size = new System.Drawing.Size(53, 20);
            this.textBoxpi2.TabIndex = 6;
            this.textBoxpi2.Text = "0.0";
            // 
            // textBoxpi5
            // 
            this.textBoxpi5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpi5.ForeColor = System.Drawing.Color.Red;
            this.textBoxpi5.Location = new System.Drawing.Point(6, 277);
            this.textBoxpi5.Name = "textBoxpi5";
            this.textBoxpi5.Size = new System.Drawing.Size(53, 20);
            this.textBoxpi5.TabIndex = 9;
            this.textBoxpi5.Text = "0.0";
            // 
            // textBoxpi3
            // 
            this.textBoxpi3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpi3.ForeColor = System.Drawing.Color.Red;
            this.textBoxpi3.Location = new System.Drawing.Point(6, 225);
            this.textBoxpi3.Name = "textBoxpi3";
            this.textBoxpi3.Size = new System.Drawing.Size(53, 20);
            this.textBoxpi3.TabIndex = 7;
            this.textBoxpi3.Text = "0.0";
            // 
            // textBoxpi6
            // 
            this.textBoxpi6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpi6.ForeColor = System.Drawing.Color.Red;
            this.textBoxpi6.Location = new System.Drawing.Point(6, 303);
            this.textBoxpi6.Name = "textBoxpi6";
            this.textBoxpi6.Size = new System.Drawing.Size(53, 20);
            this.textBoxpi6.TabIndex = 10;
            this.textBoxpi6.Text = "0.0";
            // 
            // textBoxpi7
            // 
            this.textBoxpi7.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpi7.ForeColor = System.Drawing.Color.Red;
            this.textBoxpi7.Location = new System.Drawing.Point(6, 329);
            this.textBoxpi7.Name = "textBoxpi7";
            this.textBoxpi7.Size = new System.Drawing.Size(53, 20);
            this.textBoxpi7.TabIndex = 11;
            this.textBoxpi7.Text = "0.0";
            // 
            // textBoxpi4
            // 
            this.textBoxpi4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpi4.ForeColor = System.Drawing.Color.Red;
            this.textBoxpi4.Location = new System.Drawing.Point(6, 251);
            this.textBoxpi4.Name = "textBoxpi4";
            this.textBoxpi4.Size = new System.Drawing.Size(53, 20);
            this.textBoxpi4.TabIndex = 8;
            this.textBoxpi4.Text = "0.0";
            // 
            // textBoxpi8
            // 
            this.textBoxpi8.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpi8.ForeColor = System.Drawing.Color.Red;
            this.textBoxpi8.Location = new System.Drawing.Point(6, 355);
            this.textBoxpi8.Name = "textBoxpi8";
            this.textBoxpi8.Size = new System.Drawing.Size(53, 20);
            this.textBoxpi8.TabIndex = 12;
            this.textBoxpi8.Text = "0.0";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.OldLace;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Red;
            this.label21.Location = new System.Drawing.Point(85, 151);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(70, 16);
            this.label21.TabIndex = 14;
            this.label21.Text = "Pi 630nm";
            // 
            // textBoxpi9
            // 
            this.textBoxpi9.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpi9.ForeColor = System.Drawing.Color.Red;
            this.textBoxpi9.Location = new System.Drawing.Point(90, 173);
            this.textBoxpi9.Name = "textBoxpi9";
            this.textBoxpi9.Size = new System.Drawing.Size(53, 20);
            this.textBoxpi9.TabIndex = 13;
            this.textBoxpi9.Text = "0.0";
            // 
            // textBoxpi10
            // 
            this.textBoxpi10.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpi10.ForeColor = System.Drawing.Color.Red;
            this.textBoxpi10.Location = new System.Drawing.Point(90, 200);
            this.textBoxpi10.Name = "textBoxpi10";
            this.textBoxpi10.Size = new System.Drawing.Size(53, 20);
            this.textBoxpi10.TabIndex = 14;
            this.textBoxpi10.Text = "0.0";
            // 
            // textBoxpi13
            // 
            this.textBoxpi13.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpi13.ForeColor = System.Drawing.Color.Red;
            this.textBoxpi13.Location = new System.Drawing.Point(90, 277);
            this.textBoxpi13.Name = "textBoxpi13";
            this.textBoxpi13.Size = new System.Drawing.Size(53, 20);
            this.textBoxpi13.TabIndex = 17;
            this.textBoxpi13.Text = "0.0";
            // 
            // textBoxpi11
            // 
            this.textBoxpi11.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpi11.ForeColor = System.Drawing.Color.Red;
            this.textBoxpi11.Location = new System.Drawing.Point(90, 225);
            this.textBoxpi11.Name = "textBoxpi11";
            this.textBoxpi11.Size = new System.Drawing.Size(53, 20);
            this.textBoxpi11.TabIndex = 15;
            this.textBoxpi11.Text = "0.0";
            // 
            // textBoxpi14
            // 
            this.textBoxpi14.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpi14.ForeColor = System.Drawing.Color.Red;
            this.textBoxpi14.Location = new System.Drawing.Point(90, 303);
            this.textBoxpi14.Name = "textBoxpi14";
            this.textBoxpi14.Size = new System.Drawing.Size(53, 20);
            this.textBoxpi14.TabIndex = 18;
            this.textBoxpi14.Text = "0.0";
            // 
            // textBoxpi15
            // 
            this.textBoxpi15.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpi15.ForeColor = System.Drawing.Color.Red;
            this.textBoxpi15.Location = new System.Drawing.Point(90, 329);
            this.textBoxpi15.Name = "textBoxpi15";
            this.textBoxpi15.Size = new System.Drawing.Size(53, 20);
            this.textBoxpi15.TabIndex = 19;
            this.textBoxpi15.Text = "0.0";
            // 
            // textBoxpi12
            // 
            this.textBoxpi12.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpi12.ForeColor = System.Drawing.Color.Red;
            this.textBoxpi12.Location = new System.Drawing.Point(90, 251);
            this.textBoxpi12.Name = "textBoxpi12";
            this.textBoxpi12.Size = new System.Drawing.Size(53, 20);
            this.textBoxpi12.TabIndex = 16;
            this.textBoxpi12.Text = "0.0";
            // 
            // textBoxpi16
            // 
            this.textBoxpi16.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpi16.ForeColor = System.Drawing.Color.Red;
            this.textBoxpi16.Location = new System.Drawing.Point(90, 355);
            this.textBoxpi16.Name = "textBoxpi16";
            this.textBoxpi16.Size = new System.Drawing.Size(53, 20);
            this.textBoxpi16.TabIndex = 20;
            this.textBoxpi16.Text = "0.0";
            // 
            // textBoxpin8
            // 
            this.textBoxpin8.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpin8.ForeColor = System.Drawing.Color.Red;
            this.textBoxpin8.Location = new System.Drawing.Point(167, 355);
            this.textBoxpin8.Name = "textBoxpin8";
            this.textBoxpin8.Size = new System.Drawing.Size(53, 20);
            this.textBoxpin8.TabIndex = 28;
            this.textBoxpin8.Text = "0.0";
            // 
            // textBoxpin7
            // 
            this.textBoxpin7.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpin7.ForeColor = System.Drawing.Color.Red;
            this.textBoxpin7.Location = new System.Drawing.Point(167, 329);
            this.textBoxpin7.Name = "textBoxpin7";
            this.textBoxpin7.Size = new System.Drawing.Size(53, 20);
            this.textBoxpin7.TabIndex = 27;
            this.textBoxpin7.Text = "0.0";
            // 
            // textBoxpin6
            // 
            this.textBoxpin6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpin6.ForeColor = System.Drawing.Color.Red;
            this.textBoxpin6.Location = new System.Drawing.Point(167, 303);
            this.textBoxpin6.Name = "textBoxpin6";
            this.textBoxpin6.Size = new System.Drawing.Size(53, 20);
            this.textBoxpin6.TabIndex = 26;
            this.textBoxpin6.Text = "0.0";
            // 
            // textBoxpin5
            // 
            this.textBoxpin5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpin5.ForeColor = System.Drawing.Color.Red;
            this.textBoxpin5.Location = new System.Drawing.Point(167, 277);
            this.textBoxpin5.Name = "textBoxpin5";
            this.textBoxpin5.Size = new System.Drawing.Size(53, 20);
            this.textBoxpin5.TabIndex = 25;
            this.textBoxpin5.Text = "0.0";
            // 
            // textBoxpin4
            // 
            this.textBoxpin4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpin4.ForeColor = System.Drawing.Color.Red;
            this.textBoxpin4.Location = new System.Drawing.Point(167, 251);
            this.textBoxpin4.Name = "textBoxpin4";
            this.textBoxpin4.Size = new System.Drawing.Size(53, 20);
            this.textBoxpin4.TabIndex = 24;
            this.textBoxpin4.Text = "0.0";
            // 
            // textBoxpin3
            // 
            this.textBoxpin3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpin3.ForeColor = System.Drawing.Color.Red;
            this.textBoxpin3.Location = new System.Drawing.Point(167, 225);
            this.textBoxpin3.Name = "textBoxpin3";
            this.textBoxpin3.Size = new System.Drawing.Size(53, 20);
            this.textBoxpin3.TabIndex = 23;
            this.textBoxpin3.Text = "0.0";
            // 
            // textBoxpin2
            // 
            this.textBoxpin2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpin2.ForeColor = System.Drawing.Color.Red;
            this.textBoxpin2.Location = new System.Drawing.Point(167, 199);
            this.textBoxpin2.Name = "textBoxpin2";
            this.textBoxpin2.Size = new System.Drawing.Size(53, 20);
            this.textBoxpin2.TabIndex = 22;
            this.textBoxpin2.Text = "0.0";
            // 
            // textBoxpin1
            // 
            this.textBoxpin1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpin1.ForeColor = System.Drawing.Color.Red;
            this.textBoxpin1.Location = new System.Drawing.Point(167, 173);
            this.textBoxpin1.Name = "textBoxpin1";
            this.textBoxpin1.Size = new System.Drawing.Size(53, 20);
            this.textBoxpin1.TabIndex = 21;
            this.textBoxpin1.Text = "0.0";
            // 
            // textBoxpin16
            // 
            this.textBoxpin16.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpin16.ForeColor = System.Drawing.Color.Red;
            this.textBoxpin16.Location = new System.Drawing.Point(253, 355);
            this.textBoxpin16.Name = "textBoxpin16";
            this.textBoxpin16.Size = new System.Drawing.Size(53, 20);
            this.textBoxpin16.TabIndex = 36;
            this.textBoxpin16.Text = "0.0";
            // 
            // textBoxpin15
            // 
            this.textBoxpin15.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpin15.ForeColor = System.Drawing.Color.Red;
            this.textBoxpin15.Location = new System.Drawing.Point(253, 329);
            this.textBoxpin15.Name = "textBoxpin15";
            this.textBoxpin15.Size = new System.Drawing.Size(53, 20);
            this.textBoxpin15.TabIndex = 35;
            this.textBoxpin15.Text = "0.0";
            // 
            // textBoxpin14
            // 
            this.textBoxpin14.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpin14.ForeColor = System.Drawing.Color.Red;
            this.textBoxpin14.Location = new System.Drawing.Point(253, 303);
            this.textBoxpin14.Name = "textBoxpin14";
            this.textBoxpin14.Size = new System.Drawing.Size(53, 20);
            this.textBoxpin14.TabIndex = 34;
            this.textBoxpin14.Text = "0.0";
            // 
            // textBoxpin13
            // 
            this.textBoxpin13.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpin13.ForeColor = System.Drawing.Color.Red;
            this.textBoxpin13.Location = new System.Drawing.Point(253, 277);
            this.textBoxpin13.Name = "textBoxpin13";
            this.textBoxpin13.Size = new System.Drawing.Size(53, 20);
            this.textBoxpin13.TabIndex = 33;
            this.textBoxpin13.Text = "0.0";
            // 
            // textBoxpin12
            // 
            this.textBoxpin12.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpin12.ForeColor = System.Drawing.Color.Red;
            this.textBoxpin12.Location = new System.Drawing.Point(253, 251);
            this.textBoxpin12.Name = "textBoxpin12";
            this.textBoxpin12.Size = new System.Drawing.Size(53, 20);
            this.textBoxpin12.TabIndex = 32;
            this.textBoxpin12.Text = "0.0";
            // 
            // textBoxpin11
            // 
            this.textBoxpin11.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpin11.ForeColor = System.Drawing.Color.Red;
            this.textBoxpin11.Location = new System.Drawing.Point(253, 225);
            this.textBoxpin11.Name = "textBoxpin11";
            this.textBoxpin11.Size = new System.Drawing.Size(53, 20);
            this.textBoxpin11.TabIndex = 31;
            this.textBoxpin11.Text = "0.0";
            // 
            // textBoxpin10
            // 
            this.textBoxpin10.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpin10.ForeColor = System.Drawing.Color.Red;
            this.textBoxpin10.Location = new System.Drawing.Point(253, 199);
            this.textBoxpin10.Name = "textBoxpin10";
            this.textBoxpin10.Size = new System.Drawing.Size(53, 20);
            this.textBoxpin10.TabIndex = 30;
            this.textBoxpin10.Text = "0.0";
            // 
            // textBoxpin9
            // 
            this.textBoxpin9.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxpin9.ForeColor = System.Drawing.Color.Red;
            this.textBoxpin9.Location = new System.Drawing.Point(253, 173);
            this.textBoxpin9.Name = "textBoxpin9";
            this.textBoxpin9.Size = new System.Drawing.Size(53, 20);
            this.textBoxpin9.TabIndex = 29;
            this.textBoxpin9.Text = "0.0";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.OldLace;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Red;
            this.label22.Location = new System.Drawing.Point(164, 151);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(81, 16);
            this.label22.TabIndex = 53;
            this.label22.Text = "PiN 450nm";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.OldLace;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Red;
            this.label23.Location = new System.Drawing.Point(251, 151);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(81, 16);
            this.label23.TabIndex = 54;
            this.label23.Text = "PiN 630nm";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(8, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 16);
            this.label2.TabIndex = 205;
            this.label2.Text = "Time Elapsed:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(66, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 16);
            this.label3.TabIndex = 205;
            this.label3.Text = "Mode:";
            // 
            // No_of_Mins
            // 
            this.No_of_Mins.Location = new System.Drawing.Point(123, 23);
            this.No_of_Mins.Name = "No_of_Mins";
            this.No_of_Mins.Size = new System.Drawing.Size(111, 20);
            this.No_of_Mins.TabIndex = 206;
            this.No_of_Mins.Text = "120";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(240, 27);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 16);
            this.label4.TabIndex = 205;
            this.label4.Text = "Minutes";
            // 
            // comboBoxMode
            // 
            this.comboBoxMode.FormattingEnabled = true;
            this.comboBoxMode.Items.AddRange(new object[] {
            "Mono Chromatic",
            "Bi-Chromatic"});
            this.comboBoxMode.Location = new System.Drawing.Point(123, 49);
            this.comboBoxMode.Name = "comboBoxMode";
            this.comboBoxMode.Size = new System.Drawing.Size(111, 21);
            this.comboBoxMode.TabIndex = 207;
            // 
            // buttonSendPi
            // 
            this.buttonSendPi.BackColor = System.Drawing.Color.DarkOrange;
            this.buttonSendPi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSendPi.Location = new System.Drawing.Point(371, 20);
            this.buttonSendPi.Name = "buttonSendPi";
            this.buttonSendPi.Size = new System.Drawing.Size(150, 37);
            this.buttonSendPi.TabIndex = 208;
            this.buttonSendPi.Text = "Send Pi Data";
            this.buttonSendPi.UseVisualStyleBackColor = false;
            this.buttonSendPi.Click += new System.EventHandler(this.buttonSendPi_Click);
            // 
            // buttonReceivePiData
            // 
            this.buttonReceivePiData.BackColor = System.Drawing.Color.DarkOrange;
            this.buttonReceivePiData.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonReceivePiData.Location = new System.Drawing.Point(544, 20);
            this.buttonReceivePiData.Name = "buttonReceivePiData";
            this.buttonReceivePiData.Size = new System.Drawing.Size(150, 37);
            this.buttonReceivePiData.TabIndex = 208;
            this.buttonReceivePiData.Text = "Validate Pi Data";
            this.buttonReceivePiData.UseVisualStyleBackColor = false;
            this.buttonReceivePiData.Click += new System.EventHandler(this.buttonReceivePiData_Click);
            // 
            // buttonValidatePi
            // 
            this.buttonValidatePi.BackColor = System.Drawing.Color.DarkOrange;
            this.buttonValidatePi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonValidatePi.Location = new System.Drawing.Point(707, 20);
            this.buttonValidatePi.Name = "buttonValidatePi";
            this.buttonValidatePi.Size = new System.Drawing.Size(150, 37);
            this.buttonValidatePi.TabIndex = 208;
            this.buttonValidatePi.Text = "Get  Pi Results";
            this.buttonValidatePi.UseVisualStyleBackColor = false;
            this.buttonValidatePi.Click += new System.EventHandler(this.buttonValidatePi_Click);
            // 
            // buttonValidateASTdata
            // 
            this.buttonValidateASTdata.BackColor = System.Drawing.Color.Pink;
            this.buttonValidateASTdata.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.5F);
            this.buttonValidateASTdata.Location = new System.Drawing.Point(544, 67);
            this.buttonValidateASTdata.Name = "buttonValidateASTdata";
            this.buttonValidateASTdata.Size = new System.Drawing.Size(150, 37);
            this.buttonValidateASTdata.TabIndex = 57;
            this.buttonValidateASTdata.Text = "Validate AST Data";
            this.buttonValidateASTdata.UseVisualStyleBackColor = false;
            this.buttonValidateASTdata.Click += new System.EventHandler(this.buttonValidateASTdata_Click);
            // 
            // buttonGetASTresult
            // 
            this.buttonGetASTresult.BackColor = System.Drawing.Color.Pink;
            this.buttonGetASTresult.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.5F);
            this.buttonGetASTresult.Location = new System.Drawing.Point(707, 67);
            this.buttonGetASTresult.Name = "buttonGetASTresult";
            this.buttonGetASTresult.Size = new System.Drawing.Size(150, 37);
            this.buttonGetASTresult.TabIndex = 57;
            this.buttonGetASTresult.Text = "Get AST Result";
            this.buttonGetASTresult.UseVisualStyleBackColor = false;
            this.buttonGetASTresult.Click += new System.EventHandler(this.buttonGetASTresult_Click);
            // 
            // textBoxPiResult
            // 
            this.textBoxPiResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxPiResult.ForeColor = System.Drawing.Color.MediumSeaGreen;
            this.textBoxPiResult.Location = new System.Drawing.Point(123, 111);
            this.textBoxPiResult.Name = "textBoxPiResult";
            this.textBoxPiResult.Size = new System.Drawing.Size(223, 29);
            this.textBoxPiResult.TabIndex = 209;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.MediumSeaGreen;
            this.label7.Location = new System.Drawing.Point(29, 117);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(88, 22);
            this.label7.TabIndex = 205;
            this.label7.Text = "Pi Result:";
            // 
            // buttonClearStrips
            // 
            this.buttonClearStrips.BackColor = System.Drawing.Color.Goldenrod;
            this.buttonClearStrips.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.5F);
            this.buttonClearStrips.Location = new System.Drawing.Point(904, 67);
            this.buttonClearStrips.Name = "buttonClearStrips";
            this.buttonClearStrips.Size = new System.Drawing.Size(150, 36);
            this.buttonClearStrips.TabIndex = 58;
            this.buttonClearStrips.Text = "Clear Strips";
            this.buttonClearStrips.UseVisualStyleBackColor = false;
            this.buttonClearStrips.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.sno,
            this.antibiotic,
            this.result});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Green;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.Location = new System.Drawing.Point(1027, 170);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(304, 458);
            this.dataGridView1.TabIndex = 210;
            // 
            // sno
            // 
            this.sno.HeaderText = "S.NO";
            this.sno.MaxInputLength = 5;
            this.sno.Name = "sno";
            this.sno.ReadOnly = true;
            this.sno.Width = 45;
            // 
            // antibiotic
            // 
            this.antibiotic.HeaderText = "ANTIBIOTIC";
            this.antibiotic.Name = "antibiotic";
            this.antibiotic.ReadOnly = true;
            this.antibiotic.Width = 120;
            // 
            // result
            // 
            this.result.FillWeight = 99F;
            this.result.HeaderText = "RESULT";
            this.result.Name = "result";
            this.result.ReadOnly = true;
            this.result.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.result.Width = 90;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(26, 78);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(91, 16);
            this.label20.TabIndex = 205;
            this.label20.Text = "Select Test:";
            // 
            // comboBoxTestName
            // 
            this.comboBoxTestName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxTestName.FormattingEnabled = true;
            this.comboBoxTestName.Items.AddRange(new object[] {
            "1-URINE",
            "2-Peritoneal fluid",
            "3-SPUTUM",
            "4-BLOOD",
            "5-PUS",
            "6-CSF",
            "7-Ascites",
            "8-Scrapping",
            "9-SWAB",
            "10-OTHERS"});
            this.comboBoxTestName.Location = new System.Drawing.Point(123, 76);
            this.comboBoxTestName.Name = "comboBoxTestName";
            this.comboBoxTestName.Size = new System.Drawing.Size(141, 24);
            this.comboBoxTestName.TabIndex = 211;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.DarkCyan;
            this.label24.Location = new System.Drawing.Point(5, 425);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(82, 22);
            this.label24.TabIndex = 205;
            this.label24.Text = "S/W Ver:";
            // 
            // textBoxSWver
            // 
            this.textBoxSWver.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSWver.ForeColor = System.Drawing.Color.DarkCyan;
            this.textBoxSWver.Location = new System.Drawing.Point(99, 419);
            this.textBoxSWver.Name = "textBoxSWver";
            this.textBoxSWver.Size = new System.Drawing.Size(223, 29);
            this.textBoxSWver.TabIndex = 209;
            // 
            // buttonSWver
            // 
            this.buttonSWver.BackColor = System.Drawing.Color.YellowGreen;
            this.buttonSWver.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSWver.Location = new System.Drawing.Point(145, 459);
            this.buttonSWver.Name = "buttonSWver";
            this.buttonSWver.Size = new System.Drawing.Size(132, 29);
            this.buttonSWver.TabIndex = 212;
            this.buttonSWver.Text = "Get S/W Version";
            this.buttonSWver.UseVisualStyleBackColor = false;
            this.buttonSWver.Click += new System.EventHandler(this.buttonSWver_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.s_no,
            this.name});
            this.dataGridView2.Location = new System.Drawing.Point(1027, 487);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(304, 150);
            this.dataGridView2.TabIndex = 213;
            this.dataGridView2.Visible = false;
            // 
            // buttonGetAntibioticName
            // 
            this.buttonGetAntibioticName.BackColor = System.Drawing.Color.Goldenrod;
            this.buttonGetAntibioticName.Location = new System.Drawing.Point(1098, 109);
            this.buttonGetAntibioticName.Name = "buttonGetAntibioticName";
            this.buttonGetAntibioticName.Size = new System.Drawing.Size(150, 23);
            this.buttonGetAntibioticName.TabIndex = 214;
            this.buttonGetAntibioticName.Text = "Get Antibiotic Names";
            this.buttonGetAntibioticName.UseVisualStyleBackColor = false;
            this.buttonGetAntibioticName.Click += new System.EventHandler(this.buttonGetAntibioticName_Click);
            // 
            // s_no
            // 
            this.s_no.HeaderText = "S.No";
            this.s_no.Name = "s_no";
            // 
            // name
            // 
            this.name.HeaderText = "ANTIBIOTIC NAME";
            this.name.Name = "name";
            this.name.Width = 200;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.OldLace;
            this.ClientSize = new System.Drawing.Size(1343, 684);
            this.Controls.Add(this.buttonGetAntibioticName);
            this.Controls.Add(this.buttonSWver);
            this.Controls.Add(this.comboBoxTestName);
            this.Controls.Add(this.textBoxSWver);
            this.Controls.Add(this.textBoxPiResult);
            this.Controls.Add(this.buttonReceivePiData);
            this.Controls.Add(this.buttonValidatePi);
            this.Controls.Add(this.buttonSendPi);
            this.Controls.Add(this.comboBoxMode);
            this.Controls.Add(this.No_of_Mins);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.textBox81);
            this.Controls.Add(this.textBox82);
            this.Controls.Add(this.textBox83);
            this.Controls.Add(this.textBox84);
            this.Controls.Add(this.textBox85);
            this.Controls.Add(this.textBox86);
            this.Controls.Add(this.textBox87);
            this.Controls.Add(this.textBox88);
            this.Controls.Add(this.textBox89);
            this.Controls.Add(this.textBox90);
            this.Controls.Add(this.textBox91);
            this.Controls.Add(this.textBox92);
            this.Controls.Add(this.textBox93);
            this.Controls.Add(this.textBox94);
            this.Controls.Add(this.textBox95);
            this.Controls.Add(this.textBox96);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.textBox65);
            this.Controls.Add(this.textBox66);
            this.Controls.Add(this.textBox67);
            this.Controls.Add(this.textBox68);
            this.Controls.Add(this.textBox69);
            this.Controls.Add(this.textBox70);
            this.Controls.Add(this.textBox71);
            this.Controls.Add(this.textBox72);
            this.Controls.Add(this.textBox73);
            this.Controls.Add(this.textBox74);
            this.Controls.Add(this.textBox75);
            this.Controls.Add(this.textBox76);
            this.Controls.Add(this.textBox77);
            this.Controls.Add(this.textBox78);
            this.Controls.Add(this.textBox79);
            this.Controls.Add(this.textBox80);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.textBox49);
            this.Controls.Add(this.textBox50);
            this.Controls.Add(this.textBox51);
            this.Controls.Add(this.textBox52);
            this.Controls.Add(this.textBox53);
            this.Controls.Add(this.textBox54);
            this.Controls.Add(this.textBox55);
            this.Controls.Add(this.textBox56);
            this.Controls.Add(this.textBox57);
            this.Controls.Add(this.textBox58);
            this.Controls.Add(this.textBox59);
            this.Controls.Add(this.textBox60);
            this.Controls.Add(this.textBox61);
            this.Controls.Add(this.textBox62);
            this.Controls.Add(this.textBox63);
            this.Controls.Add(this.textBox64);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonPaste);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.buttonClearResults);
            this.Controls.Add(this.buttonClearStrips);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBox33);
            this.Controls.Add(this.textBox34);
            this.Controls.Add(this.textBox35);
            this.Controls.Add(this.textBox36);
            this.Controls.Add(this.textBox37);
            this.Controls.Add(this.textBox38);
            this.Controls.Add(this.textBox39);
            this.Controls.Add(this.textBox40);
            this.Controls.Add(this.textBox41);
            this.Controls.Add(this.textBox42);
            this.Controls.Add(this.textBox43);
            this.Controls.Add(this.textBox44);
            this.Controls.Add(this.textBox45);
            this.Controls.Add(this.textBox46);
            this.Controls.Add(this.textBox47);
            this.Controls.Add(this.textBox48);
            this.Controls.Add(this.textBoxpin9);
            this.Controls.Add(this.textBox25);
            this.Controls.Add(this.textBoxpin10);
            this.Controls.Add(this.textBox26);
            this.Controls.Add(this.textBoxpin11);
            this.Controls.Add(this.textBox27);
            this.Controls.Add(this.textBoxpin12);
            this.Controls.Add(this.textBox28);
            this.Controls.Add(this.textBoxpin13);
            this.Controls.Add(this.textBox29);
            this.Controls.Add(this.textBoxpin14);
            this.Controls.Add(this.textBox30);
            this.Controls.Add(this.textBoxpin15);
            this.Controls.Add(this.textBox31);
            this.Controls.Add(this.textBoxpin16);
            this.Controls.Add(this.textBox32);
            this.Controls.Add(this.textBoxpin1);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.textBoxpin2);
            this.Controls.Add(this.textBox18);
            this.Controls.Add(this.textBoxpin3);
            this.Controls.Add(this.textBox19);
            this.Controls.Add(this.textBoxpin4);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.textBoxpin5);
            this.Controls.Add(this.textBox21);
            this.Controls.Add(this.textBoxpin6);
            this.Controls.Add(this.textBox22);
            this.Controls.Add(this.textBoxpin7);
            this.Controls.Add(this.textBox23);
            this.Controls.Add(this.textBoxpin8);
            this.Controls.Add(this.textBox24);
            this.Controls.Add(this.textBoxpi16);
            this.Controls.Add(this.textBox16);
            this.Controls.Add(this.textBoxpi12);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBoxpi15);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.textBoxpi14);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.textBoxpi11);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBoxpi13);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.textBoxpi10);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBoxpi9);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBoxpi8);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBoxpi4);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBoxpi7);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBoxpi6);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBoxpi3);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBoxpi5);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBoxpi2);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBoxpi1);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.button_OpenPort);
            this.Controls.Add(this.comboBox_COMPORT);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonGetASTresult);
            this.Controls.Add(this.buttonValidateASTdata);
            this.Controls.Add(this.buttonSend);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "UTI SIMULATOR";
            this.Load += new System.EventHandler(this.OnLoadForm);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox_COMPORT;
        private System.Windows.Forms.Button button_OpenPort;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button buttonSend;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button buttonPaste;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.TextBox textBox61;
        private System.Windows.Forms.TextBox textBox62;
        private System.Windows.Forms.TextBox textBox63;
        private System.Windows.Forms.TextBox textBox64;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox65;
        private System.Windows.Forms.TextBox textBox66;
        private System.Windows.Forms.TextBox textBox67;
        private System.Windows.Forms.TextBox textBox68;
        private System.Windows.Forms.TextBox textBox69;
        private System.Windows.Forms.TextBox textBox70;
        private System.Windows.Forms.TextBox textBox71;
        private System.Windows.Forms.TextBox textBox72;
        private System.Windows.Forms.TextBox textBox73;
        private System.Windows.Forms.TextBox textBox74;
        private System.Windows.Forms.TextBox textBox75;
        private System.Windows.Forms.TextBox textBox76;
        private System.Windows.Forms.TextBox textBox77;
        private System.Windows.Forms.TextBox textBox78;
        private System.Windows.Forms.TextBox textBox79;
        private System.Windows.Forms.TextBox textBox80;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox81;
        private System.Windows.Forms.TextBox textBox82;
        private System.Windows.Forms.TextBox textBox83;
        private System.Windows.Forms.TextBox textBox84;
        private System.Windows.Forms.TextBox textBox85;
        private System.Windows.Forms.TextBox textBox86;
        private System.Windows.Forms.TextBox textBox87;
        private System.Windows.Forms.TextBox textBox88;
        private System.Windows.Forms.TextBox textBox89;
        private System.Windows.Forms.TextBox textBox90;
        private System.Windows.Forms.TextBox textBox91;
        private System.Windows.Forms.TextBox textBox92;
        private System.Windows.Forms.TextBox textBox93;
        private System.Windows.Forms.TextBox textBox94;
        private System.Windows.Forms.TextBox textBox95;
        private System.Windows.Forms.TextBox textBox96;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button buttonClearResults;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBoxpi1;
        private System.Windows.Forms.TextBox textBoxpi2;
        private System.Windows.Forms.TextBox textBoxpi5;
        private System.Windows.Forms.TextBox textBoxpi3;
        private System.Windows.Forms.TextBox textBoxpi6;
        private System.Windows.Forms.TextBox textBoxpi7;
        private System.Windows.Forms.TextBox textBoxpi4;
        private System.Windows.Forms.TextBox textBoxpi8;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBoxpi9;
        private System.Windows.Forms.TextBox textBoxpi10;
        private System.Windows.Forms.TextBox textBoxpi13;
        private System.Windows.Forms.TextBox textBoxpi11;
        private System.Windows.Forms.TextBox textBoxpi14;
        private System.Windows.Forms.TextBox textBoxpi15;
        private System.Windows.Forms.TextBox textBoxpi12;
        private System.Windows.Forms.TextBox textBoxpi16;
        private System.Windows.Forms.TextBox textBoxpin8;
        private System.Windows.Forms.TextBox textBoxpin7;
        private System.Windows.Forms.TextBox textBoxpin6;
        private System.Windows.Forms.TextBox textBoxpin5;
        private System.Windows.Forms.TextBox textBoxpin4;
        private System.Windows.Forms.TextBox textBoxpin3;
        private System.Windows.Forms.TextBox textBoxpin2;
        private System.Windows.Forms.TextBox textBoxpin1;
        private System.Windows.Forms.TextBox textBoxpin16;
        private System.Windows.Forms.TextBox textBoxpin15;
        private System.Windows.Forms.TextBox textBoxpin14;
        private System.Windows.Forms.TextBox textBoxpin13;
        private System.Windows.Forms.TextBox textBoxpin12;
        private System.Windows.Forms.TextBox textBoxpin11;
        private System.Windows.Forms.TextBox textBoxpin10;
        private System.Windows.Forms.TextBox textBoxpin9;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox No_of_Mins;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBoxMode;
        private System.Windows.Forms.Button buttonSendPi;
        private System.Windows.Forms.Button buttonReceivePiData;
        private System.Windows.Forms.Button buttonValidatePi;
        private System.Windows.Forms.Button buttonValidateASTdata;
        private System.Windows.Forms.Button buttonGetASTresult;
        private System.Windows.Forms.TextBox textBoxPiResult;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button buttonClearStrips;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sno;
        private System.Windows.Forms.DataGridViewTextBoxColumn antibiotic;
        private System.Windows.Forms.DataGridViewTextBoxColumn result;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox comboBoxTestName;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBoxSWver;
        private System.Windows.Forms.Button buttonSWver;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button buttonGetAntibioticName;
        private System.Windows.Forms.DataGridViewTextBoxColumn s_no;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
    }
}